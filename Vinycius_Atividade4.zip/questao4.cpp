#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct Aluno {
    string nome;
    string matricula;
    double notas[3];
};

double calcularMedia(Aluno aluno) {
    return (aluno.notas[0] + aluno.notas[1] + aluno.notas[2]) / 3.0;
}

int main() {
    Aluno aluno;

    cout << "Digite o nome do aluno: ";
    getline(cin, aluno.nome);

    cout << "Digite a matricula: ";
    getline(cin, aluno.matricula);

    for (int i = 0; i < 3; i++) {
        cout << "Digite a nota " << i + 1 << ": ";
        cin >> aluno.notas[i];
    }

    double media = calcularMedia(aluno);

    cout << fixed << setprecision(2);
    cout << "\n--- Dados do aluno ---\n";
    cout << "Nome: " << aluno.nome << endl;
    cout << "Matricula: " << aluno.matricula << endl;
    cout << "Nota 1: " << aluno.notas[0] << endl;
    cout << "Nota 2: " << aluno.notas[1] << endl;
    cout << "Nota 3: " << aluno.notas[2] << endl;
    cout << "Media: " << media << endl;

    return 0;
}
