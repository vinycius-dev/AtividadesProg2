LISTA DE EXERCICIOS - TIPOS ESTRUTURADOS EM C++

Arquivos:
1. questao1.cpp - Estrutura Data
2. questao2.cpp - Funcao soma
3. questao3.cpp - Conversao de dolares para reais com inline
4. questao4.cpp - Struct Aluno e calculo de media
5. questao5.cpp - Sobrecarga da funcao calculaQuadrado
6. questao6.cpp - Matriz de despesas
7. questao7.cpp - Array dinamico e media
8. questao8.cpp - Insercao em array dinamico
9. desafio_remocao.cpp - Desafio complementar: remocao em array dinamico

COMPILACAO COM G++

No terminal, entre na pasta dos arquivos e use:

g++ questao1.cpp -o questao1
g++ questao2.cpp -o questao2
g++ questao3.cpp -o questao3
g++ questao4.cpp -o questao4
g++ questao5.cpp -o questao5
g++ questao6.cpp -o questao6
g++ questao7.cpp -o questao7
g++ questao8.cpp -o questao8
g++ desafio_remocao.cpp -o desafio_remocao

No Windows/PowerShell, para executar, por exemplo:

.\questao1.exe
.\questao2.exe

Os exercicios foram separados em arquivos independentes para facilitar a entrega
e a compilacao.
