#include <iostream>
using namespace std;

struct Data {
    int dia;
    int mes;
    int ano;
};

int main() {
    Data data;

    cout << "Digite o dia: ";
    cin >> data.dia;
    cout << "Digite o mes: ";
    cin >> data.mes;
    cout << "Digite o ano: ";
    cin >> data.ano;

    cout << "\nData armazenada: "
         << data.dia << "/" << data.mes << "/" << data.ano << endl;

    return 0;
}
