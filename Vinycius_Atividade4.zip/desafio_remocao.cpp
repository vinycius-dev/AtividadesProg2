#include <iostream>
using namespace std;

int main() {
    int quantidade;

    cout << "Digite a quantidade de elementos: ";
    cin >> quantidade;

    if (quantidade <= 0) {
        cout << "A quantidade deve ser maior que zero." << endl;
        return 1;
    }

    double* valores = new double[quantidade];

    for (int i = 0; i < quantidade; i++) {
        cout << "Digite o valor " << i + 1 << ": ";
        cin >> valores[i];
    }

    int posicao;
    cout << "\nDigite a posicao do elemento que deseja remover (1 a "
         << quantidade << "): ";
    cin >> posicao;

    if (posicao < 1 || posicao > quantidade) {
        cout << "Posicao invalida." << endl;
        delete[] valores;
        return 1;
    }

    double* novoArray = new double[quantidade - 1];

    int j = 0;
    for (int i = 0; i < quantidade; i++) {
        if (i != posicao - 1) {
            novoArray[j] = valores[i];
            j++;
        }
    }

    delete[] valores;
    valores = novoArray;
    quantidade--;

    cout << "\nArray apos a remocao: ";
    for (int i = 0; i < quantidade; i++) {
        cout << valores[i] << " ";
    }
    cout << endl;

    delete[] valores;
    valores = nullptr;

    return 0;
}
