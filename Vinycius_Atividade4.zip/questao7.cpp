#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int quantidade;

    cout << "Digite a quantidade de elementos: ";
    cin >> quantidade;

    if (quantidade <= 0) {
        cout << "A quantidade deve ser maior que zero." << endl;
        return 1;
    }

    double* valores = new double[quantidade];
    double soma = 0.0;

    for (int i = 0; i < quantidade; i++) {
        cout << "Digite o valor " << i + 1 << ": ";
        cin >> valores[i];
        soma += valores[i];
    }

    double media = soma / quantidade;

    cout << fixed << setprecision(2);
    cout << "\nMedia dos valores: " << media << endl;

    delete[] valores;
    valores = nullptr;

    return 0;
}
