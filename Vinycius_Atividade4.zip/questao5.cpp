#include <iostream>
using namespace std;

int calculaQuadrado(int valor) {
    return valor * valor;
}

double calculaQuadrado(double valor) {
    return valor * valor;
}

int main() {
    int numeroInteiro;
    double numeroDouble;

    cout << "Digite um numero inteiro: ";
    cin >> numeroInteiro;

    cout << "Digite um numero decimal: ";
    cin >> numeroDouble;

    cout << "Quadrado do inteiro: " << calculaQuadrado(numeroInteiro) << endl;
    cout << "Quadrado do decimal: " << calculaQuadrado(numeroDouble) << endl;

    return 0;
}
