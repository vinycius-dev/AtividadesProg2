#include <iostream>
#include <iomanip>
using namespace std;

inline double converterDolaresParaReais(double dolares, double cotacao) {
    return dolares * cotacao;
}

int main() {
    double dolares, cotacao;

    cout << "Digite a quantia em dolares: ";
    cin >> dolares;
    cout << "Digite a cotacao do dolar em reais: ";
    cin >> cotacao;

    double reais = converterDolaresParaReais(dolares, cotacao);

    cout << fixed << setprecision(2);
    cout << "Valor em reais: R$ " << reais << endl;

    return 0;
}
