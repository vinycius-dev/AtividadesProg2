#include <iostream>
#include <iomanip>
using namespace std;

const int ANO = 2;
const int TRIMESTRE = 4;

int main() {
    double despesas[ANO][TRIMESTRE];
    double totalGeral = 0.0;

    for (int ano = 0; ano < ANO; ano++) {
        cout << "\nDespesas do ano " << ano + 1 << ":\n";

        for (int trimestre = 0; trimestre < TRIMESTRE; trimestre++) {
            cout << "Digite a despesa do " << trimestre + 1 << "o trimestre: R$ ";
            cin >> despesas[ano][trimestre];
        }
    }

    cout << fixed << setprecision(2);
    cout << "\n========== TABELA DE DESPESAS ==========\n";
    cout << "Ano\tT1\tT2\tT3\tT4\tTotal\n";

    for (int ano = 0; ano < ANO; ano++) {
        double totalAno = 0.0;

        cout << ano + 1 << "\t";

        for (int trimestre = 0; trimestre < TRIMESTRE; trimestre++) {
            cout << despesas[ano][trimestre] << "\t";
            totalAno += despesas[ano][trimestre];
            totalGeral += despesas[ano][trimestre];
        }

        cout << totalAno << endl;
    }

    cout << "========================================\n";
    cout << "Total geral: R$ " << totalGeral << endl;

    return 0;
}
