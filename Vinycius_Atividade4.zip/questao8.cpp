#include <iostream>
using namespace std;

int main() {
    int quantidade;

    cout << "Digite a quantidade de elementos: ";
    cin >> quantidade;

    if (quantidade < 0) {
        cout << "Quantidade invalida." << endl;
        return 1;
    }

    double* valores = nullptr;

    if (quantidade > 0) {
        valores = new double[quantidade];

        for (int i = 0; i < quantidade; i++) {
            cout << "Digite o valor " << i + 1 << ": ";
            cin >> valores[i];
        }
    }

    double novoValor;
    cout << "Digite o novo valor para inserir ao final: ";
    cin >> novoValor;

    double* novoArray = new double[quantidade + 1];

    for (int i = 0; i < quantidade; i++) {
        novoArray[i] = valores[i];
    }

    novoArray[quantidade] = novoValor;

    delete[] valores;
    valores = novoArray;
    quantidade++;

    cout << "\nArray final: ";
    for (int i = 0; i < quantidade; i++) {
        cout << valores[i] << " ";
    }
    cout << endl;

    delete[] valores;
    valores = nullptr;

    return 0;
}
