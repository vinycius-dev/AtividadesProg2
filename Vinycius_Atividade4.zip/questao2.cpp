#include <iostream>
using namespace std;

int soma(int a, int b) {
    return a + b;
}

int main() {
    int valor1, valor2;

    cout << "Digite o primeiro valor inteiro: ";
    cin >> valor1;
    cout << "Digite o segundo valor inteiro: ";
    cin >> valor2;

    cout << "Soma: " << soma(valor1, valor2) << endl;

    return 0;
}
