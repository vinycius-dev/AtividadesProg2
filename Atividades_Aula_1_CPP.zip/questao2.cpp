#include <iostream>
using namespace std;

int main() {
    cout << "Vinycius Eduardo\n";
    cout << "Barra do Garças";

    return 0;
}
