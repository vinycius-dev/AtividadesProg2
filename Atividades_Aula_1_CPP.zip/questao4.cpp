#include <iostream>
using namespace std;

int main() {
    int numero;

    cout << "Digite um numero: ";
    cin >> numero;

    cout << "O triplo e: " << numero * 3;

    return 0;
}
