#include <iostream>
using namespace std;

int main() {
    int numero;

    cout << "Digite um numero: ";
    cin >> numero;

    cout << "O dobro e: " << numero * 2;

    return 0;
}
