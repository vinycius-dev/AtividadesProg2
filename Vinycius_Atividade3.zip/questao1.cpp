#include <iostream>
using namespace std;

int main() {
    int ano;

    cout << "Digite um ano: ";
    cin >> ano;

    if (ano >= 1930 && (ano - 1930) % 4 == 0) {
        cout << "Havera Copa neste ano.";
    } else {
        cout << "Nao havera Copa neste ano.";
    }

    return 0;
}
