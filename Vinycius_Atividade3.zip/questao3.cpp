#include <iostream>
using namespace std;

int main() {
    int idade;

    cout << "Digite sua idade: ";
    cin >> idade;

    if (idade >= 0 && idade <= 1) {
        cout << "Bebe";
    }
    else if (idade >= 2 && idade <= 10) {
        cout << "Crianca";
    }
    else if (idade >= 11 && idade <= 17) {
        cout << "Adolescente";
    }
    else if (idade >= 18 && idade <= 64) {
        cout << "Adulto";
    }
    else if (idade >= 65 && idade <= 100) {
        cout << "Idoso";
    }
    else {
        cout << "Idade invalida";
    }

    return 0;
}
