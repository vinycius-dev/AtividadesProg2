#include <iostream>
using namespace std;

int main() {
    int numero;
    int a = 0, b = 1, proximo;

    cout << "Digite um numero inteiro: ";
    cin >> numero;

    cout << "Fibonacci: ";

    while (a <= numero) {
        cout << a << " ";

        proximo = a + b;
        a = b;
        b = proximo;
    }

    return 0;
}
