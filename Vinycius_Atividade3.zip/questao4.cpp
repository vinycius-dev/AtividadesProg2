#include <iostream>
using namespace std;

int main() {
    double salario, novoSalario;

    cout << "Digite o salario: R$ ";
    cin >> salario;

    if (salario < 3000) {
        novoSalario = salario * 1.50;
    }
    else if (salario <= 10000) {
        novoSalario = salario * 1.20;
    }
    else {
        novoSalario = salario * 1.15;
    }

    cout << "Novo salario: R$ " << novoSalario;

    return 0;
}
