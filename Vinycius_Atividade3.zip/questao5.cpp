#include <iostream>
using namespace std;

int main() {
    int numero;
    long long fatorial = 1;

    cout << "Digite um numero inteiro: ";
    cin >> numero;

    if (numero < 0) {
        cout << "Nao existe fatorial de numero negativo.";
    }
    else {
        for (int i = 1; i <= numero; i++) {
            fatorial = fatorial * i;
        }

        cout << "O fatorial de " << numero << " e: " << fatorial;
    }

    return 0;
}
