#include <iostream>
using namespace std;

void inverterSinais(int *a, int *b) {
    *a = -(*a);
    *b = -(*b);
}

int main() {
    int a, b;

    cout << "Digite o primeiro valor: ";
    cin >> a;

    cout << "Digite o segundo valor: ";
    cin >> b;

    cout << "\nAntes da execucao:" << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;

    inverterSinais(&a, &b);

    cout << "\nDepois da execucao:" << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;

    return 0;
}
