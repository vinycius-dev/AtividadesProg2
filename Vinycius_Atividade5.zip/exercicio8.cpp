#include <iostream>
using namespace std;

int multiplicar(int a, int b) {
    return a * b;
}

int somar(int a, int b) {
    return a + b;
}

int main() {
    int a, b;

    cout << "Digite o primeiro valor: ";
    cin >> a;

    cout << "Digite o segundo valor: ";
    cin >> b;

    int (*operacao)(int, int);

    operacao = somar;
    cout << "\nResultado da soma: " << operacao(a, b) << endl;

    operacao = multiplicar;
    cout << "Resultado da multiplicacao: " << operacao(a, b) << endl;

    return 0;
}
