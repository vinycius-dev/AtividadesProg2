#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double a[100];
    double* aPtr = a;
    int quantidade;

    cout << "Quantos valores deseja informar (1 a 100)? ";
    cin >> quantidade;

    if (quantidade < 1 || quantidade > 100) {
        cout << "Quantidade invalida." << endl;
        return 1;
    }

    for (int j = 0; j < quantidade; j++) {
        cout << "Digite o valor " << j + 1 << ": ";
        cin >> *(a + j);
    }

    double soma = 0.0;

    for (int j = 0; j < quantidade; j++) {
        soma += *(aPtr + j);
    }

    double media = soma / quantidade;

    cout << fixed << setprecision(2);
    cout << "\nSoma total: " << soma << endl;
    cout << "Media aritmetica: " << media << endl;

    return 0;
}
