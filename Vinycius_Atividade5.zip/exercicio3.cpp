#include <iostream>
using namespace std;

int main() {
    int val = 50;
    int* ptr = &val;

    *ptr = 100;

    cout << "Valor final de val: " << val << endl;
    cout << "Valor final atraves de *ptr: " << *ptr << endl;

    return 0;
}
