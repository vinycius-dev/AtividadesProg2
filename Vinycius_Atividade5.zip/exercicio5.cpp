#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    float* numero = new float;

    cout << "Digite um valor: ";
    cin >> *numero;

    float quadrado = (*numero) * (*numero);

    cout << fixed << setprecision(2);
    cout << "Quadrado do valor: " << quadrado << endl;

    delete numero;
    numero = nullptr;

    return 0;
}
