LISTA DE EXERCICIOS - PONTEIROS EM C++

Conteudo:

exercicio1.cpp
- Variaveis inteiras x e y.
- Exibe valores e enderecos de memoria usando &.

exercicio2.cpp
- Array de double com capacidade para 100 valores.
- Leitura usando obrigatoriamente cin >> *(a + j).
- Acumulo usando soma += *(aPtr + j).
- Calcula soma e media.

exercicio3.cpp
- Ponteiro para uma variavel inteira.
- Altera o valor da variavel atraves do operador *.

exercicio4.cpp
- Array de 5 inteiros.
- Percorre utilizando apenas um ponteiro e aritmetica de ponteiros.
- Exibe elementos e enderecos.

exercicio5.cpp
- Alocacao dinamica de um float usando new.
- Calcula o quadrado.
- Libera memoria usando delete.

exercicio6.cpp
- Array dinamico de inteiros usando new int[N].
- Leitura dos elementos.
- Encontra o maior valor.
- Libera memoria usando delete[].

exercicio7.cpp
- Funcao inverterSinais(int *a, int *b).
- Inverte os sinais dos dois valores atraves de ponteiros.

exercicio8.cpp
- Funcoes somar e multiplicar.
- Ponteiro para funcao int (*operacao)(int, int).
- Executa as duas operacoes usando o mesmo ponteiro.

COMO COMPILAR COM G++

Exemplo:
g++ exercicio1.cpp -o exercicio1

Depois execute:
Windows/PowerShell:
.\exercicio1.exe

Linux:
./exercicio1

Repita o mesmo processo para os demais arquivos.
