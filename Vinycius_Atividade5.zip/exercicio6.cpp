#include <iostream>
using namespace std;

int main() {
    int N;

    cout << "Digite a quantidade de elementos: ";
    cin >> N;

    if (N <= 0) {
        cout << "A quantidade deve ser maior que zero." << endl;
        return 1;
    }

    int* vetor = new int[N];

    for (int i = 0; i < N; i++) {
        cout << "Digite o elemento " << i + 1 << ": ";
        cin >> vetor[i];
    }

    int maior = vetor[0];

    for (int i = 1; i < N; i++) {
        if (vetor[i] > maior) {
            maior = vetor[i];
        }
    }

    cout << "Maior valor: " << maior << endl;

    delete[] vetor;
    vetor = nullptr;

    return 0;
}
