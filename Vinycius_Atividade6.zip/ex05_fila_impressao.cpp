// Exercício 5 — Fila de documentos (std::queue<string>)
// FIFO (First In, First Out): o primeiro documento enviado é o primeiro impresso.

#include <iostream>
#include <queue>
#include <string>
#include <limits>
using namespace std;

int lerOpcao() {
    int op;
    while (!(cin >> op)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida: ";
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return op;
}

void demonstracaoFIFO() {
    cout << "\n--- Demonstracao FIFO ---" << endl;
    queue<string> f;
    f.push("relatorio.pdf");
    f.push("foto.png");
    f.push("contrato.docx");
    cout << "Ordem de chegada: relatorio.pdf, foto.png, contrato.docx" << endl;
    cout << "Ordem de impressao: ";
    while (!f.empty()) {
        cout << f.front() << "  ";
        f.pop();
    }
    cout << "\n=> O primeiro a entrar foi o primeiro a sair." << endl;
}

int main() {
    queue<string> fila;
    int op;

    do {
        cout << "\n===== FILA DE IMPRESSAO =====" << endl;
        cout << "1 - Adicionar documento" << endl;
        cout << "2 - Processar (imprimir) proximo documento" << endl;
        cout << "3 - Consultar proximo (sem remover)" << endl;
        cout << "4 - Verificar se a fila esta vazia" << endl;
        cout << "5 - Demonstracao da regra FIFO" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        op = lerOpcao();

        switch (op) {
            case 1: {
                cout << "Nome do documento: ";
                string doc;
                getline(cin, doc);
                fila.push(doc); // entra no FINAL da fila
                cout << "Adicionado. Documentos na fila: " << fila.size() << endl;
                break;
            }
            case 2:
                if (fila.empty()) {
                    cout << "Nenhum documento para imprimir." << endl;
                } else {
                    cout << "Imprimindo: " << fila.front() << endl;
                    fila.pop(); // sai do INICIO da fila
                }
                break;
            case 3:
                if (fila.empty())
                    cout << "Fila vazia." << endl;
                else
                    cout << "Proximo a imprimir: " << fila.front() << endl;
                break;
            case 4:
                cout << (fila.empty() ? "A fila esta vazia." : "A fila NAO esta vazia.")
                     << endl;
                break;
            case 5:
                demonstracaoFIFO();
                break;
            case 0:
                cout << "Encerrando..." << endl;
                break;
            default:
                cout << "Opcao invalida." << endl;
        }
    } while (op != 0);

    return 0;
}
