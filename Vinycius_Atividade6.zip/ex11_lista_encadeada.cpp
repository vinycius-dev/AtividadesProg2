// Exercício 11 — Construção de lista simplesmente encadeada

#include <iostream>
using namespace std;

struct No {
    int valor;
    No* proximo;
};

// Insere no final da lista
void inserirFinal(No*& cabeca, int valor) {
    No* novo = new No{valor, nullptr};
    if (cabeca == nullptr) {     // lista vazia: o novo nó vira a cabeça
        cabeca = novo;
        return;
    }
    No* atual = cabeca;
    while (atual->proximo != nullptr) // anda até o último nó
        atual = atual->proximo;
    atual->proximo = novo;
}

void exibir(const No* cabeca) {
    const No* atual = cabeca;
    while (atual != nullptr) {
        cout << atual->valor << " -> ";
        atual = atual->proximo;
    }
    cout << "nullptr" << endl;
}

// Libera todos os nós
void liberar(No*& cabeca) {
    int liberados = 0;
    while (cabeca != nullptr) {
        No* temp = cabeca;          // guarda o nó atual
        cabeca = cabeca->proximo;   // avança ANTES de apagar
        delete temp;
        liberados++;
    }
    cout << liberados << " no(s) liberado(s). Lista agora: "
         << (cabeca == nullptr ? "vazia" : "?") << endl;
}

int main() {
    No* lista = nullptr;

    int valores[] = {10, 20, 30, 40, 50, 60};
    for (int v : valores)
        inserirFinal(lista, v);

    cout << "Lista encadeada: ";
    exibir(lista);

    liberar(lista);
    return 0;
}
