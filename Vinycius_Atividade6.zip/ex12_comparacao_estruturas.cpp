// Exercício 12 — Comparação entre lista, fila e pilha
//
// Resumo (relatório):
//
// | Estrutura | Inserção                       | Remoção                         | Regra  | Aplicação prática                |
// |-----------|--------------------------------|---------------------------------|--------|----------------------------------|
// | Lista     | qualquer posição (push_front,  | qualquer posição (pop_front,    | nenhuma| playlist / lista de tarefas,     |
// |           | push_back, insert)             | pop_back, erase, remove)        | fixa   | onde se insere e remove no meio  |
// | Fila      | só no final (push)             | só no início (pop)              | FIFO   | fila de impressão, atendimento,  |
// |           |                                |                                 |        | buffer de teclado / rede         |
// | Pilha     | só no topo (push)              | só no topo (pop)                | LIFO   | desfazer (Ctrl+Z), botão voltar  |
// |           |                                |                                 |        | do navegador, chamadas de função |
//
// O programa abaixo insere os mesmos valores (1, 2, 3) em cada estrutura e
// mostra a ordem em que saem.

#include <iostream>
#include <list>
#include <queue>
#include <stack>
using namespace std;

int main() {
    cout << "Inserindo 1, 2, 3 em cada estrutura...\n" << endl;

    // ---------- LISTA ----------
    list<int> lista;
    lista.push_back(1);
    lista.push_back(2);
    lista.push_back(3);
    lista.push_front(0);            // pode inserir no inicio
    auto it = next(lista.begin(), 2);
    lista.insert(it, 99);           // ... ou no meio
    cout << "LISTA (apos push_front(0) e insert(99) no meio): ";
    for (int x : lista) cout << x << " ";
    lista.remove(99);               // remove de qualquer posicao
    cout << "\n  apos remove(99): ";
    for (int x : lista) cout << x << " ";
    cout << "\n  -> acesso livre as duas pontas e ao meio; nao segue FIFO nem LIFO.\n" << endl;

    // ---------- FILA ----------
    queue<int> fila;
    fila.push(1);
    fila.push(2);
    fila.push(3);
    cout << "FILA  - ordem de saida: ";
    while (!fila.empty()) {
        cout << fila.front() << " ";
        fila.pop();
    }
    cout << "\n  -> entra no final, sai do inicio: FIFO (First In, First Out).\n" << endl;

    // ---------- PILHA ----------
    stack<int> pilha;
    pilha.push(1);
    pilha.push(2);
    pilha.push(3);
    cout << "PILHA - ordem de saida: ";
    while (!pilha.empty()) {
        cout << pilha.top() << " ";
        pilha.pop();
    }
    cout << "\n  -> entra e sai pelo topo: LIFO (Last In, First Out).\n" << endl;

    cout << "Aplicacoes praticas:" << endl;
    cout << "  Lista: playlist de musicas (adicionar/remover em qualquer posicao)" << endl;
    cout << "  Fila : fila de impressao ou de atendimento (ordem de chegada)" << endl;
    cout << "  Pilha: desfazer (Ctrl+Z) em editores e botao 'voltar' do navegador" << endl;
    return 0;
}
