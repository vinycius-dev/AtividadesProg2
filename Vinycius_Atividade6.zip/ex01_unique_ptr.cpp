// Exercício 1 — Refatoração com ponteiro inteligente
//
// Código original (gerenciamento manual):
//     int *ptr = new int(42);
//     std::cout << *ptr << std::endl;
//     delete ptr;
//
// Problema do original: se o programador esquecer o delete, ou se uma exceção
// / return antecipado acontecer antes dele, a memória vaza. Também existe o
// risco de delete duplo ou de usar o ponteiro depois de liberado.

#include <iostream>
#include <memory>
using namespace std;

int main() {
    unique_ptr<int> ptr = make_unique<int>(42);

    cout << "Valor apontado: " << *ptr << endl;

    // Não existe delete aqui.
    //
    // Por que a liberação manual deixa de ser necessária?
    // - unique_ptr segue o princípio RAII (Resource Acquisition Is Initialization):
    //   o recurso (a memória) fica "amarrado" ao tempo de vida do objeto ptr.
    // - Quando ptr sai de escopo (aqui, no fim do main), o destrutor de
    //   unique_ptr é chamado automaticamente e executa o delete por nós.
    // - Isso vale mesmo se a função terminar por exceção ou por um return
    //   antecipado, então não há vazamento.
    // - make_unique cria o objeto e o unique_ptr numa única operação, sem
    //   expor um "new" solto no código.
    // - unique_ptr não pode ser copiado (posse exclusiva), então nunca haverá
    //   dois donos tentando liberar a mesma memória (delete duplo).
    return 0;
}
