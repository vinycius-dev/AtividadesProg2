// Exercício 7 — Editor de texto com pilha (std::stack<string>)
// LIFO (Last In, First Out): a última palavra digitada é a primeira desfeita.

#include <iostream>
#include <stack>
#include <string>
#include <vector>
#include <limits>
using namespace std;

int lerOpcao() {
    int op;
    while (!(cin >> op)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida: ";
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return op;
}

// Mostra o texto na ordem em que foi digitado.
// Recebe uma CÓPIA da pilha, então a original não é alterada.
void mostrarTexto(stack<string> p) {
    vector<string> palavras;
    while (!p.empty()) {          // sai do topo (última) para a base (primeira)
        palavras.push_back(p.top());
        p.pop();
    }
    cout << "Texto: \"";
    for (int i = (int)palavras.size() - 1; i >= 0; i--) {
        cout << palavras[i];
        if (i > 0) cout << " ";
    }
    cout << "\"" << endl;
}

int main() {
    stack<string> editor;
    int op;

    do {
        cout << "\n===== EDITOR (PILHA) =====" << endl;
        cout << "1 - Digitar palavra" << endl;
        cout << "2 - Desfazer ultima palavra (pop)" << endl;
        cout << "3 - Ver palavra no topo (top)" << endl;
        cout << "4 - Mostrar texto atual" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        op = lerOpcao();

        switch (op) {
            case 1: {
                cout << "Palavra: ";
                string w;
                cin >> w;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                editor.push(w);
                break;
            }
            case 2:
                if (editor.empty()) {
                    cout << "Nada para desfazer." << endl;
                } else {
                    cout << "Desfeito: \"" << editor.top() << "\"" << endl;
                    editor.pop();
                }
                break;
            case 3:
                if (editor.empty())
                    cout << "Editor vazio." << endl;
                else
                    cout << "Topo: \"" << editor.top() << "\"" << endl;
                break;
            case 4:
                break;
            case 0:
                cout << "Encerrando..." << endl;
                continue;
            default:
                cout << "Opcao invalida." << endl;
        }
        mostrarTexto(editor);
    } while (op != 0);

    // LIFO: cada desfazer remove sempre a palavra mais recente (o topo),
    // exatamente como o Ctrl+Z de um editor real.
    return 0;
}
