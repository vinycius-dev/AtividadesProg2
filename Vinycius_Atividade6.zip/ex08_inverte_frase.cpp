// Exercício 8 — Inversão de frase com pilha

#include <iostream>
#include <sstream>
#include <stack>
#include <string>
using namespace std;

int main() {
    string frase;
    cout << "Digite uma frase: ";
    getline(cin, frase);

    stack<string> pilha;
    stringstream ss(frase);
    string palavra;
    while (ss >> palavra)      // separa a frase em palavras
        pilha.push(palavra);   // cada palavra vai para o topo

    cout << "Frase invertida: ";
    while (!pilha.empty()) {
        cout << pilha.top();   // sempre lê o topo (última inserida)
        pilha.pop();
        if (!pilha.empty()) cout << " ";
    }
    cout << endl;

    // Por que a última palavra inserida é a primeira a sair?
    // A pilha só dá acesso a UMA extremidade: o topo. Cada push coloca a nova
    // palavra em cima das anteriores, então a última palavra lida fica no topo.
    // Como pop() também só retira do topo, a primeira a sair é justamente a
    // última que entrou (LIFO — Last In, First Out). Retirando todas, obtemos
    // as palavras na ordem exatamente inversa à de inserção.
    return 0;
}
