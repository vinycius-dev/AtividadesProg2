// Exercício 10 — Fila de inteiros implementada manualmente (array circular)
//
// Como a ordem FIFO é garantida:
// - "inicio" aponta para o elemento mais antigo; "fim" para a próxima posição livre.
// - Inserção (enfileirar) só acontece em "fim"; remoção (desenfileirar) só em "inicio".
// - Assim, os elementos saem exatamente na mesma ordem em que entraram.
// - O array é CIRCULAR: os índices avançam com (i + 1) % CAPACIDADE, para
//   reaproveitar as posições liberadas no começo do vetor sem precisar
//   deslocar elementos.

#include <iostream>
using namespace std;

const int CAPACIDADE = 5;

class Fila {
private:
    int dados[CAPACIDADE];
    int inicio;     // posição do primeiro elemento
    int fim;        // posição onde entra o próximo
    int quantidade; // número de elementos armazenados

public:
    Fila() : inicio(0), fim(0), quantidade(0) {}

    bool vazia() const { return quantidade == 0; }
    bool cheia() const { return quantidade == CAPACIDADE; }

    bool enfileirar(int valor) {
        if (cheia()) {
            cout << "  Erro: fila cheia, " << valor << " nao inserido." << endl;
            return false;
        }
        dados[fim] = valor;
        fim = (fim + 1) % CAPACIDADE;
        quantidade++;
        return true;
    }

    bool desenfileirar(int& valor) {
        if (vazia()) {
            cout << "  Erro: fila vazia, nada para remover." << endl;
            return false;
        }
        valor = dados[inicio];
        inicio = (inicio + 1) % CAPACIDADE;
        quantidade--;
        return true;
    }

    void exibir() const {
        cout << "  Fila (inicio -> fim): [ ";
        for (int i = 0, pos = inicio; i < quantidade; i++, pos = (pos + 1) % CAPACIDADE)
            cout << dados[pos] << " ";
        cout << "]" << endl;
    }
};

int main() {
    Fila f;
    int v;

    cout << "Fila vazia? " << (f.vazia() ? "sim" : "nao") << endl;

    cout << "\nInserindo 1, 2, 3, 4, 5, 6:" << endl;
    for (int x = 1; x <= 6; x++) f.enfileirar(x); // 6 excede a capacidade
    f.exibir();

    cout << "\nRemovendo dois elementos:" << endl;
    for (int i = 0; i < 2; i++)
        if (f.desenfileirar(v)) cout << "  Saiu: " << v << endl;
    f.exibir();

    cout << "\nInserindo 7 e 8 (reaproveitando o espaco, array circular):" << endl;
    f.enfileirar(7);
    f.enfileirar(8);
    f.exibir();

    cout << "\nRemovendo tudo (+1 tentativa extra):" << endl;
    while (true) {
        if (!f.desenfileirar(v)) break;
        cout << "  Saiu: " << v << endl;
    }
    cout << "=> Ordem de saida 1,2,3,4,5,7,8 = ordem de entrada (FIFO)." << endl;
    return 0;
}
