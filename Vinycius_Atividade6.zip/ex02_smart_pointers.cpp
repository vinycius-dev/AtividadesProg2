// Exercício 2 — Comparação entre smart pointers
// unique_ptr  -> posse exclusiva (um único dono, só pode ser movido)
// shared_ptr  -> posse compartilhada (contagem de referências: use_count())
// weak_ptr    -> observa um shared_ptr sem ser dono (não aumenta use_count);
//                lock() devolve um shared_ptr válido se o objeto ainda existir

#include <iostream>
#include <memory>
#include <string>
using namespace std;

struct Recurso {
    string nome;
    Recurso(const string& n) : nome(n) { cout << "  [criado] " << nome << endl; }
    ~Recurso() { cout << "  [destruido] " << nome << endl; }
};

void verificar(const weak_ptr<Recurso>& w) {
    if (shared_ptr<Recurso> tmp = w.lock())
        cout << "  lock(): objeto ainda existe -> " << tmp->nome << endl;
    else
        cout << "  lock(): objeto ja foi destruido (retornou nullptr)" << endl;
}

int main() {
    // ---------------- unique_ptr ----------------
    cout << "=== unique_ptr: posse exclusiva ===" << endl;
    {
        unique_ptr<Recurso> u1 = make_unique<Recurso>("A");
        // unique_ptr<Recurso> u2 = u1;   // ERRO de compilacao: nao pode copiar
        unique_ptr<Recurso> u2 = move(u1); // a posse e TRANSFERIDA
        cout << "  u1 apos move: " << (u1 ? "valido" : "nullptr") << endl;
        cout << "  u2 agora e o dono de: " << u2->nome << endl;
        cout << "  saindo do escopo..." << endl;
    } // u2 destroi "A" aqui

    // ---------------- shared_ptr ----------------
    cout << "\n=== shared_ptr: contagem de referencias ===" << endl;
    weak_ptr<Recurso> observador;
    {
        shared_ptr<Recurso> s1 = make_shared<Recurso>("B");
        cout << "  s1 criado        -> use_count = " << s1.use_count() << endl;
        {
            shared_ptr<Recurso> s2 = s1; // copia: mais um dono
            cout << "  s2 = s1          -> use_count = " << s1.use_count() << endl;
            shared_ptr<Recurso> s3 = s2;
            cout << "  s3 = s2          -> use_count = " << s1.use_count() << endl;
        } // s2 e s3 deixam de existir
        cout << "  s2 e s3 sairam   -> use_count = " << s1.use_count() << endl;

        // ---------------- weak_ptr ----------------
        cout << "\n=== weak_ptr: observa sem ser dono ===" << endl;
        observador = s1;
        cout << "  weak_ptr criado  -> use_count = " << s1.use_count()
             << " (nao mudou)" << endl;
        verificar(observador);
        cout << "  saindo do escopo de s1..." << endl;
    } // ultimo dono (s1) sai: "B" e destruido

    verificar(observador);
    cout << "  expired() = " << boolalpha << observador.expired() << endl;
    return 0;
}
