// Exercício 4 — Operações com lista de inteiros (std::list<int>)

#include <iostream>
#include <list>
#include <limits>
using namespace std;

int lerInt() {
    int v;
    while (!(cin >> v)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida. Digite um inteiro: ";
    }
    return v;
}

void exibir(const list<int>& l) {
    cout << "Lista (" << l.size() << " elementos): [ ";
    for (int x : l) cout << x << " ";
    cout << "]" << endl;
}

int main() {
    list<int> numeros;
    int op;

    do {
        cout << "\n===== LISTA DE INTEIROS =====" << endl;
        cout << "1 - Inserir valor" << endl;
        cout << "2 - Remover o primeiro elemento" << endl;
        cout << "3 - Remover o ultimo elemento" << endl;
        cout << "4 - Remover todas as ocorrencias de um valor" << endl;
        cout << "5 - Exibir lista" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        op = lerInt();

        switch (op) {
            case 1: {
                cout << "Valor: ";
                int v = lerInt();
                numeros.push_back(v);
                break;
            }
            case 2:
                if (numeros.empty()) {
                    cout << "Lista vazia! Nao ha o que remover." << endl;
                    break;
                }
                cout << "Removido: " << numeros.front() << endl;
                numeros.pop_front();
                break;
            case 3:
                if (numeros.empty()) {
                    cout << "Lista vazia! Nao ha o que remover." << endl;
                    break;
                }
                cout << "Removido: " << numeros.back() << endl;
                numeros.pop_back();
                break;
            case 4: {
                if (numeros.empty()) {
                    cout << "Lista vazia! Nao ha o que remover." << endl;
                    break;
                }
                cout << "Valor a remover: ";
                int v = lerInt();
                size_t antes = numeros.size();
                numeros.remove(v);
                cout << (antes - numeros.size()) << " ocorrencia(s) removida(s)." << endl;
                break;
            }
            case 5:
                break; // a lista ja e exibida logo abaixo
            case 0:
                cout << "Encerrando..." << endl;
                continue;
            default:
                cout << "Opcao invalida." << endl;
        }
        exibir(numeros); // exibe a lista atualizada apos cada operacao
    } while (op != 0);

    return 0;
}
