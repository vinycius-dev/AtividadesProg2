// Exercício 9 — Pilha de inteiros implementada manualmente com array

#include <iostream>
using namespace std;

const int CAPACIDADE = 5;

class Pilha {
private:
    int dados[CAPACIDADE];
    int topo; // índice do elemento do topo; -1 significa pilha vazia

public:
    Pilha() : topo(-1) {}

    bool vazia() const { return topo == -1; }
    bool cheia() const { return topo == CAPACIDADE - 1; }
    int tamanho() const { return topo + 1; }

    bool empilhar(int valor) {
        if (cheia()) {
            cout << "  Erro: pilha cheia (overflow), " << valor << " nao empilhado." << endl;
            return false;
        }
        dados[++topo] = valor;
        return true;
    }

    bool desempilhar(int& valor) {
        if (vazia()) {
            cout << "  Erro: pilha vazia (underflow), nada para desempilhar." << endl;
            return false;
        }
        valor = dados[topo--];
        return true;
    }

    bool consultarTopo(int& valor) const {
        if (vazia()) {
            cout << "  Pilha vazia, nao ha topo." << endl;
            return false;
        }
        valor = dados[topo];
        return true;
    }

    void exibir() const {
        cout << "  Pilha (base -> topo): [ ";
        for (int i = 0; i <= topo; i++) cout << dados[i] << " ";
        cout << "]  tamanho=" << tamanho() << "/" << CAPACIDADE << endl;
    }
};

int main() {
    Pilha p;
    int v;

    cout << "Pilha vazia? " << (p.vazia() ? "sim" : "nao") << endl;

    cout << "\nEmpilhando 10, 20, 30, 40, 50, 60:" << endl;
    for (int x = 10; x <= 60; x += 10) p.empilhar(x); // 60 estoura a capacidade
    p.exibir();

    if (p.consultarTopo(v)) cout << "Topo: " << v << endl;

    cout << "\nDesempilhando tudo (+1 tentativa extra):" << endl;
    for (int i = 0; i < CAPACIDADE + 1; i++)
        if (p.desempilhar(v)) cout << "  Desempilhado: " << v << endl;

    p.exibir();
    cout << "Pilha vazia? " << (p.vazia() ? "sim" : "nao") << endl;
    return 0;
}
