// Exercício 6 — Fila de atendimento (std::queue<string>)
// A ordem de chegada é mantida porque queue só permite inserir no final (push)
// e remover do início (pop).

#include <iostream>
#include <queue>
#include <string>
#include <limits>
using namespace std;

int lerOpcao() {
    int op;
    while (!(cin >> op)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida: ";
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return op;
}

int main() {
    queue<string> atendimento;
    int senha = 0;
    int op;

    do {
        cout << "\n===== FILA DE ATENDIMENTO =====" << endl;
        cout << "1 - Adicionar pessoa" << endl;
        cout << "2 - Chamar proxima pessoa" << endl;
        cout << "3 - Quantas pessoas aguardam" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        op = lerOpcao();

        switch (op) {
            case 1: {
                cout << "Nome: ";
                string nome;
                getline(cin, nome);
                atendimento.push(nome);
                cout << nome << " entrou na fila (posicao " << atendimento.size() << ")." << endl;
                break;
            }
            case 2:
                // impede a remoção com a fila vazia
                if (atendimento.empty()) {
                    cout << "Ninguem aguardando. Nao ha quem chamar." << endl;
                } else {
                    senha++;
                    cout << "Chamada " << senha << ": " << atendimento.front()
                         << ", dirija-se ao guiche." << endl;
                    atendimento.pop();
                }
                break;
            case 3:
                cout << "Pessoas aguardando: " << atendimento.size() << endl;
                break;
            case 0:
                cout << "Encerrando..." << endl;
                break;
            default:
                cout << "Opcao invalida." << endl;
        }
    } while (op != 0);

    return 0;
}
