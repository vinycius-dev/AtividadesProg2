// Exercício 3 — Lista de tarefas com std::list<string>

#include <iostream>
#include <list>
#include <string>
#include <limits>
using namespace std;

int lerOpcao() {
    int op;
    while (!(cin >> op)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Entrada invalida. Digite um numero: ";
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // descarta o '\n'
    return op;
}

void listar(const list<string>& tarefas) {
    if (tarefas.empty()) {
        cout << "Nenhuma tarefa cadastrada." << endl;
        return;
    }
    int i = 1;
    for (const string& t : tarefas)
        cout << i++ << ". " << t << endl;
}

int main() {
    list<string> tarefas;
    int op;

    do {
        cout << "\n===== GERENCIADOR DE TAREFAS =====" << endl;
        cout << "1 - Inserir tarefa no inicio" << endl;
        cout << "2 - Inserir tarefa no final" << endl;
        cout << "3 - Remover tarefa (pelo texto)" << endl;
        cout << "4 - Listar tarefas" << endl;
        cout << "5 - Quantidade de tarefas" << endl;
        cout << "0 - Sair" << endl;
        cout << "Opcao: ";
        op = lerOpcao();

        string texto;
        switch (op) {
            case 1:
                cout << "Tarefa: ";
                getline(cin, texto);
                tarefas.push_front(texto);
                cout << "Inserida no inicio." << endl;
                break;
            case 2:
                cout << "Tarefa: ";
                getline(cin, texto);
                tarefas.push_back(texto);
                cout << "Inserida no final." << endl;
                break;
            case 3: {
                if (tarefas.empty()) {
                    cout << "Lista vazia, nada para remover." << endl;
                    break;
                }
                cout << "Texto da tarefa a remover: ";
                getline(cin, texto);
                size_t antes = tarefas.size();
                tarefas.remove(texto); // remove todas as ocorrencias iguais
                if (tarefas.size() < antes)
                    cout << "Tarefa removida." << endl;
                else
                    cout << "Tarefa nao encontrada." << endl;
                break;
            }
            case 4:
                listar(tarefas);
                break;
            case 5:
                cout << "Quantidade de tarefas: " << tarefas.size() << endl;
                break;
            case 0:
                cout << "Encerrando..." << endl;
                break;
            default:
                cout << "Opcao invalida." << endl;
        }
    } while (op != 0);

    return 0;
}
