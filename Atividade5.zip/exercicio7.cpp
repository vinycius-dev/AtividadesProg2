#include <iostream>
using namespace std;

void inverterSinais(int *a, int *b) {
    *a = -(*a);
    *b = -(*b);
}

int main() {
    int a, b;

    cout << "Digite o primeiro valor: ";
    cin >> a;
    cout << "Digite o segundo valor: ";
    cin >> b;

    cout << "Antes: a = " << a << ", b = " << b << endl;

    inverterSinais(&a, &b);

    cout << "Depois: a = " << a << ", b = " << b << endl;

    return 0;
}
