ATIVIDADE - PONTEIROS EM C++

8 exercicios separados em arquivos .cpp.

Exercicio 2:
- Array double[100]
- leitura: cin >> *(a + j);
- acumulacao: soma += *(aPtr + j);

Exercicio 4:
- utiliza *(ptr + i) e (ptr + i).

Exercicio 5:
- utiliza new e delete.

Exercicio 6:
- utiliza new int[N] e delete[].

Exercicio 7:
- funcao void inverterSinais(int *a, int *b).

Exercicio 8:
- ponteiro int (*operacao)(int, int).

Para compilar:
g++ exercicio1.cpp -o exercicio1

No Windows:
.\exercicio1.exe
