#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    float *numero = new float;

    cout << "Digite um valor: ";
    cin >> *numero;

    cout << fixed << setprecision(2);
    cout << "Quadrado: " << (*numero) * (*numero) << endl;

    delete numero;
    numero = nullptr;

    return 0;
}
