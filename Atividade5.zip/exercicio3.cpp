#include <iostream>
using namespace std;

int main() {
    int val = 50;
    int *ptr = &val;

    *ptr = 100;

    cout << "val diretamente: " << val << endl;
    cout << "*ptr: " << *ptr << endl;

    return 0;
}
