#include <iostream>
using namespace std;

int main() {
    int valores[5] = {10, 20, 30, 40, 50};
    int *ptr = &valores[0];

    for (int i = 0; i < 5; i++) {
        cout << "Elemento " << i << ": " << *(ptr + i)
             << " | Endereco: " << (ptr + i) << endl;
    }

    return 0;
}
